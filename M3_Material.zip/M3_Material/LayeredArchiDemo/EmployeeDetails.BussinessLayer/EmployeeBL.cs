﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;
using EmployeeDetails.DataAccessLayer;
using EmployeeDetails.ExceptionClass;

namespace EmployeeDetails.BussinessLayer
{
    public class EmployeeBL
    {

        private static bool ValidateEmp(Employees emp)
        {
            StringBuilder sb = new StringBuilder();

            bool validEmp = true;

            if (emp.EmpId < 0)
            {
                validEmp = false;
                sb.Append(Environment.NewLine + "Enter valid EmpID");
            }
            if (emp.EmpName == string.Empty)
            {
                validEmp = false;
                sb.Append(Environment.NewLine + "Employee Name Required");
            }
            if (emp.EmpDate.ToString().Length < 0)
            {
                validEmp = false;
                sb.Append(Environment.NewLine + "Enter valid Date");
            }

            if (validEmp == false)
            {
                throw new EmployeeClassException(sb.ToString());
            }

            return validEmp;
        }

        public static List<Employees> GetAllEmpBL()
        {
            List<Employees> empList = null;
            try
            {
                EmployeeDAL empDAL = new EmployeeDAL();
                empList = empDAL.SelectAllDAL();
            }
            catch (EmployeeClassException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return empList;
        }

        public static bool AddEmpBL(Employees emp)
        {
            bool empAdded = false;

            try
            {
                if (ValidateEmp(emp))
                {
                    EmployeeDAL empDAL = new EmployeeDAL();
                    empAdded = empDAL.InsertDAL(emp);
                }
            }
            catch (EmployeeClassException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return empAdded;
        }

        //public static Guest SearchGuestBL(int searchEmpID)
        //{
        //    Employees searchedEmp = null;

        //    try
        //    {
        //        EmployeeDAL guestDAL = new EmployeeDAL();
        //        searchedEmp = guestDAL.SearchGuestDAL(searchGuestID);
        //    }
        //    catch (EmployeeClassException)
        //    {
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return searchedEmp;
        //}

        public static bool UpdateEmpBL(Employees emp)
        {
            bool empUpdated = false;

            try
            {
                if (ValidateEmp(emp))
                {
                    EmployeeDAL empDAL = new EmployeeDAL();
                    empUpdated = empDAL.UpdateDAL(emp);
                }
            }
            catch (EmployeeClassException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return empUpdated;
        }

        public static bool DeleteEmpBL(int empId)
        {
            bool empDeleted = false;

            try
            {
                if (empId >0)
                {
                    EmployeeDAL empDAL = new EmployeeDAL();
                    empDeleted = empDAL.DeleteDAL(empId);
                    
                }
                else
                {
                    throw new EmployeeClassException("Invalid Emp ID");
                }
            }
            catch (EmployeeClassException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return empDeleted;
        }

        public static List<Employees> selectAllBL()
        {
            List<Employees> empList = null;
            try
            {
                EmployeeDAL empDAL = new EmployeeDAL();
                empList = empDAL.SelectAllDAL();
            }
            catch (EmployeeClassException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return empList;

        }
    }
}
