﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LayeredDemo.BusinessLayer;
using LayeredDemo.DataAccessLayer;
using LayeredDemo.Entitiy;
using LayeredDemo.Exceptions;


namespace LayeredDemo.Presentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Product p = null;
        ProductBL productBL = new ProductBL();
        public MainWindow()
        {
            InitializeComponent();
        }
        private bool IsValid()
        {
            StringBuilder sb = new StringBuilder();

            bool isValid = true;
            
            if (comboname.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Employee Name Required");
            }
            if (datepicker.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Date Required");
            }
            if(txtPrice.Text==string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Date Required");
            }

            if (isValid == false)
            {
                throw new UDExceptions(sb.ToString());
            }

            return isValid;
        }
        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    p = new Product()
                    {

                        ProductName = comboname.Text,
                        Price = Convert.ToDecimal(txtPrice.Text),
                        ExpDate = Convert.ToDateTime(datepicker.Text)

                    };
                    status = ProductBL.AddProdBL(p);
                 
                }
                else
                {
                    MessageBox.Show("Enter Data");
                }
                if (status == true)
                    MessageBox.Show("Inserted");
                PopulateUI();
            }
            catch(UDExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                bool status = false;
                // p = (Product)comboname.SelectedItem;
                if (IsValid())
                {



                    p.ProductName = comboname.Text;
                    p.ExpDate = Convert.ToDateTime(datepicker.Text);
                    p.Price = Convert.ToDecimal(txtPrice.Text);

                    status = ProductBL.UpdateProdBL(p);
                }
                if(status==true)
                 MessageBox.Show("Updated");
               PopulateUI();


            }
            catch(UDExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btndelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                 p = (Product)comboname.SelectedItem;
                ProductBL.DeleteProdBL(p);
                MessageBox.Show("Deleted");
                PopulateUI();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void PopulateUI()
        {
            IEnumerable<Product> prods = ProductBL.selectAllBL();
            dgProducts.ItemsSource = prods;
            comboname.ItemsSource = prods;
            comboname.DisplayMemberPath = "ProductName";
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
            
        }

        private void Comboname_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Btn_Edit_Click(object sender, RoutedEventArgs e)
        {
            p = (Product)comboname.SelectedItem;
        }
    }
}
