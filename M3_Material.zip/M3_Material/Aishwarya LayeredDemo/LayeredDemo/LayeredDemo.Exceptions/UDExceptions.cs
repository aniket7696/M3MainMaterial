﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayeredDemo.Exceptions
{
    public class UDExceptions : ApplicationException
    {
        public UDExceptions() : base()
        {

        }

        public UDExceptions(string message) : base(message)
        {

        }

        public UDExceptions(string message, Exception objEx) : base(message, objEx)
        {

        }
    }
}
