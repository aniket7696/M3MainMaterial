﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }
        public void PopulateUI()
        {
            //List<Product> prods= dbContext.Products.ToList();
            //var res= prods.OrderByDescending(s => s.Id);

            //dgProducts.ItemsSource = res;
            //cmbProdname.ItemsSource = res;
            //cmbProdname.DisplayMemberPath = "ProdName";

            List<Student> stud = dbContext.Students.ToList();
            dgStudent.ItemsSource = stud;
            cmbName.ItemsSource = stud;
            cmbName.DisplayMemberPath = "StudentName";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            Student stud = new Student();
            stud.StudentName = cmbName.Text;
            stud.Age = Convert.ToInt32(txtAge.Text);
            stud.DOJ = Convert.ToDateTime(dpDOJ.Text);
            dbContext.Students.Add(stud);
            dbContext.SaveChanges();
            MessageBox.Show("Inserted");
            PopulateUI();
        }

        int id;

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Student stud = dbContext.Students.Single(p => p.Id == id);
            stud.StudentName = cmbName.Text;
            stud.Age = Convert.ToInt32(txtAge.Text);
            stud.DOJ = Convert.ToDateTime(dpDOJ.Text);
            dbContext.SaveChanges();
            MessageBox.Show("UPDATED!!");
            PopulateUI();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

            //int _id = ((Product)cmbProdName.SelectedItem).Id;

            //Product prod = dbContext.Products.Single(p => p.Id == _id);

            Student stud = (Student)cmbName.SelectedItem;

            dbContext.Students.Remove(stud);
            dbContext.SaveChanges();
            MessageBox.Show("Deleted");
            PopulateUI();
        }

    private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            id = ((Student)cmbName.SelectedItem).Id;
        }
    }
}
