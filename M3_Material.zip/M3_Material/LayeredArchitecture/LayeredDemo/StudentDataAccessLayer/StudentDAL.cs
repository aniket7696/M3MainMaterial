﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentEntities;
using StudentExceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace StudentDataAccessLayer
{
    public class StudentDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public bool InsertDAL(Student stud)
        {
            bool StudentAdded = false;
            try
            {
                cmd = new SqlCommand("ashriran.InsertStudent77", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Name", stud.StudentName);
                cmd.Parameters.AddWithValue("@age", stud.Age);
                cmd.Parameters.AddWithValue("@Date", stud.DOJ);
                cn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    StudentAdded = true;
            }
            catch (Exception ex)
            {

                throw new StudentException(ex.Message);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return StudentAdded;
        }

        public bool UpdateDAL(Student stud)
        {
            bool StudentUpdated = false;
            try
            {
                cmd = new SqlCommand("ashriran.UpdateStud77", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", stud.Id);
                cmd.Parameters.AddWithValue("@Name", stud.StudentName);
                cmd.Parameters.AddWithValue("@age", stud.Age);
                cmd.Parameters.AddWithValue("@Date", stud.DOJ);
                cn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    StudentUpdated = true;
            }
            catch (Exception ex)
            {
                throw new StudentException(ex.Message);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return StudentUpdated;
        }

        public bool DeleteDAL(Student stud)
        {
            bool StudentDeleted = false;
            try
            {
                cmd = new SqlCommand("ashriran.DeleteStud77", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", stud.Id);
                cn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    StudentDeleted = true;
            }
            catch (Exception ex)
            {
                throw new StudentException(ex.Message);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }

            return StudentDeleted;
        }

        public List<Student> SelectAllDAL()
        {
            List<Student> StudList = new List<Student>();

            try
            {

                cmd = new SqlCommand("select * from ashriran.Student", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Student stud = new Student();
                        stud.Id = Convert.ToInt32(dr[0]);
                        stud.StudentName = dr[1].ToString();
                        stud.Age = Convert.ToInt32(dr[2]);
                        stud.DOJ = Convert.ToDateTime(dr[3]);
                        
                        StudList.Add(stud);

                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw new StudentException(ex.Message);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return StudList;
        }
    }
}
