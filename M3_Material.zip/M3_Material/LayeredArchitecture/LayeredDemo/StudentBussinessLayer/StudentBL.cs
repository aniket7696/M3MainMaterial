﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentEntities;
using StudentExceptions;
using StudentDataAccessLayer;

namespace StudentBussinessLayer
{
    public class StudentBL
    {
        private static bool ValidateStud(Student stud)
        {
            StringBuilder sb = new StringBuilder();

            bool validStud = true;

            if (stud.Id < 0)
            {
                validStud = false;
                sb.Append(Environment.NewLine + "Enter valid ID");
            }
            if (stud.StudentName == string.Empty)
            {
                validStud = false;
                sb.Append(Environment.NewLine + "Student Name Required");
            }
            if (stud.Age < 0 | stud.Age > 30)
            {
                validStud = false;
                sb.Append(Environment.NewLine + "Enter valid Age");

            }
            if (stud.DOJ.ToString().Length < 0)
            {
                validStud = false;
                sb.Append(Environment.NewLine + "Enter valid Date");
            }

            if (validStud == false)
            {
                throw new StudentException(sb.ToString());
            }

            return validStud;
        }

        public static List<Student> GetAllStudBL()
        {
            List<Student> StudList = null;
            try
            {
                StudentDAL DAL = new StudentDAL();
                StudList = DAL.SelectAllDAL();
            }
            catch (StudentException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StudList;
        }

        public static bool AddStudBL(Student stud)
        {
            bool StudAdded = false;

            try
            {
                if (ValidateStud(stud))
                {
                    StudentDAL DAL = new StudentDAL();
                    StudAdded = DAL.InsertDAL(stud);
                }
            }
            catch (StudentException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StudAdded;
        }

        public static bool UpdateStudBL(Student stud)
        {
            bool StudUpdated = false;

            try
            {
                if (ValidateStud(stud))
                {
                    StudentDAL DAL = new StudentDAL();
                    StudUpdated = DAL.UpdateDAL(stud);
                }
            }
            catch (StudentException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StudUpdated;
        }

        public static bool DeleteStudBL(Student stud)
        {
            bool StudDeleted = false;

            try
            {
                
                    StudentDAL DAL = new StudentDAL();
                    StudDeleted = DAL.DeleteDAL(stud);

               
            }
            catch (StudentException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StudDeleted;
        }

        public static List<Student> selectAllBL()
        {
            List<Student> StudList = null;
            try
            {
                StudentDAL DAL = new StudentDAL();
                StudList = DAL.SelectAllDAL();
            }
            catch (StudentException ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StudList;

        }
    }
}
